// Require node_modules

const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const app = express();

// Configure dotenv package

require('dotenv').config();

// Set up our openweathermap API_KEY

const apiKey = `${process.env.API_KEY}`; 
//for test only, show api key
console.log(apiKey);



// Setup our express app and body-parser configurations
// Setup our javascript template view engine
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

// Setup our default display on launch
app.get('/', function(req, res) {

    // It shall not fetch and display any data in the index page
    res.render('index', { weather: null, error: null });
});

// On a post request, the app shall data from OpenWeatherMap using the given arguments
app.post('/', function(req, res) {

    // Get city name passed in the form
    let city = req.body.city;
    console.log(req.body.city);
    // Use that city name to fetch data
    // Use the API_KEY in the '.env' file

    

    /*let url1 = `http://api.openweathermap.org/data/2.5/forecast?q=${city}&cnt=7&appid=${apiKey}`;

    console.log(url1);
    request(url1, function(err, response, body) {
        if (err) {
            res.render('index', { weather: null, error: 'Error, please try again' });
        } else {
            let forcast = JSON.parse(body);
            console.log(forcast);
        }
    });*/

    let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
    console.log(url);
    // Request for data using the URL
    request(url, function(err, response, body) {

        // On return, check the json data fetched
        if (err) {
            res.render('index', { weather: null, error: 'Error, please try again' });
        } else {
            let weather = JSON.parse(body);

            // We shall output it in the console just to make sure that the data being displayed is what we want
            console.log(weather);

            if (weather.main == undefined) {
                res.render('index', { weather: null, error: 'Error, please try again' });
            } else {
                // we shall use the data got to set up our output
                let place = `${weather.name}, ${weather.sys.country}`,
                    weatherTemp = `${weather.main.temp}`,
                    weatherPressure = `${weather.main.pressure}`,
                    // We shall fetch the weather icon and its size using the icon data
                    humidity = `${weather.main.humidity}`,
                    clouds = `${weather.clouds.all}`,
                    visibility = `${weather.visibility}`,
                    condition = `${weather.weather[0].main}`,
                    weatherFahrenheit;
                    weatherFahrenheit = ((weatherTemp * 9 / 5) + 32);

                // round value of the degrees & fahrenheit
                function roundToTwo(num) {
                    return +(Math.round(num + "e+2") + "e-2");
                }
                weatherFahrenheit = roundToTwo(weatherFahrenheit);

                // We shall now render the data to our page (index.ejs) before displaying it out
                res.render('index', { weather: weather, place: place, temp: weatherTemp, pressure: weatherPressure,  humidity: humidity, fahrenheit: weatherFahrenheit, clouds: clouds, visibility: visibility, condition: condition, error: null });
            }
        }
    });
});

// We shall set up our port configurations
app.listen(5000, function() {
    console.log('Weather app listening on port 5000!');
});